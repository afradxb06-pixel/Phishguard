/*************************************************
 * GLOBAL PAGE HANDLER
 *************************************************/
window.onload = function () {
    if (window.location.pathname.includes("result.html")) {
        const scannedTarget = localStorage.getItem("checkedURL");
        const scanResult = localStorage.getItem("scanResult");

        if (!scannedTarget || !scanResult) {
            window.location.href = "index.html";
            return;
        }

        runScanSequence(scanResult, scannedTarget);
    }
};

/*************************************************
 * SCAN VISUALIZER
 *************************************************/
function runScanSequence(finalResult, target) {
    const steps = ["step1", "step2", "step3", "step4"];
    let index = 0;

    function nextStep() {
        if (index < steps.length) {
            const el = document.getElementById(steps[index]);
            el.classList.add("active");

            setTimeout(() => {
                el.classList.remove("active");
                el.classList.add("done");
                el.querySelector(".step-icon").innerHTML = "✓";
                index++;
                nextStep();
            }, 750);
        } else {
            setTimeout(() => showFinalResult(finalResult, target), 500);
        }
    }

    nextStep();
}

/*************************************************
 * FINAL RESULT DISPLAY
 *************************************************/
function showFinalResult(resultText, target) {
    document.getElementById("scanSteps").style.display = "none";
    document.getElementById("resultContent").style.display = "block";
    document.getElementById("scannedUrl").innerText = target;

    const resultEl = document.getElementById("result");
    const icon = document.getElementById("resultIcon");

    resultEl.innerText = resultText;

    if (resultText.includes("Safe")) {
        icon.innerHTML = `<svg class="path-check" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>`;
        resultEl.style.color = "var(--success)";
    } else if (resultText.includes("Suspicious")) {
        icon.innerHTML = `
            <svg class="path-cross" viewBox="0 0 24 24">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>`;
        resultEl.style.color = "orange";
    } else {
        icon.innerHTML = `
            <svg class="path-cross" viewBox="0 0 24 24">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>`;
        resultEl.style.color = "var(--danger)";
    }

    document.getElementById("resultContent").scrollIntoView({ behavior: "smooth" });
}

/*************************************************
 * MAIN SCAN ENTRY
 *************************************************/
async function checkInput() {
    const input = document.getElementById("scanInput").value.trim();
    const error = document.getElementById("error");
    error.innerText = "";

    if (!input) {
        error.innerText = "Please paste a URL or email content to scan";
        return;
    }

    let result;
    let scannedTarget;

    if (looksLikeURL(input)) {
        scannedTarget = input;
        result = await scanURL(input);
    } else {
        scannedTarget = "Email Content Scan";
        result = detectEmailPhishing(input);
    }

    localStorage.setItem("checkedURL", scannedTarget);
    localStorage.setItem("scanResult", result);
    window.location.href = "result.html";
}

/*************************************************
 * URL DETECTION
 *************************************************/
function looksLikeURL(text) {
    return (
        text.startsWith("http://") ||
        text.startsWith("https://") ||
        /\b[a-z0-9-]+\.[a-z]{2,}/i.test(text)
    );
}

/*************************************************
 * ONLINE DATABASE CHECK
 *************************************************/
async function scanURL(url) {
    const onlineCheck = await checkOnlineDatabase(url);
    if (onlineCheck !== "Unknown") return onlineCheck;
    return detectURLPhishing(url);
}

async function checkOnlineDatabase(url) {
    try {
        const response = await fetch(
            "https://api.allorigins.win/raw?url=https://openphish.com/feed.txt"
        );
        const data = await response.text();
        if (data.includes(url)) {
            return "Phishing Website (Reported Online)";
        }
        return "Unknown";
    } catch {
        return "Unknown";
    }
}

/*************************************************
 * IMPROVED URL PHISHING HEURISTICS
 *************************************************/
function detectURLPhishing(url) {
    const u = url.toLowerCase();
    let score = 0;

    const shadyTLDs = [
        ".xyz", ".top", ".tk", ".shop", ".club", ".online",
        ".click", ".support", ".zip", ".mov"
    ];

    // Raw IP
    if (/\b\d{1,3}(\.\d{1,3}){3}\b/.test(u)) score += 3;

    // Too many dots
    if ((u.match(/\./g) || []).length > 3) score += 1;

    // @ symbol
    if (u.includes("@")) score += 3;

    // HTTP only
    if (u.startsWith("http://")) score += 2;

    // Suspicious TLD
    if (shadyTLDs.some(tld => u.endsWith(tld))) score += 2;

    // VERY short domain (shortener behavior)
    const domain = u.replace(/^https?:\/\//, "").split("/")[0];
    if (domain.length <= 6) score += 3;

    // Short random path like t.ly/-68eK
    if (/\/[a-z0-9-_]{4,8}$/i.test(u)) score += 3;

    // High-entropy path
    if (/\/[a-z0-9]{10,}/i.test(u)) score += 2;

    if (score >= 7) return "Phishing Website";
    if (score >= 3) return "Suspicious Website";
    return "Safe Website";
}

/*************************************************
 * EMAIL PHISHING
 *************************************************/
function detectEmailPhishing(content) {
    const text = content.toLowerCase();
    let score = 0;

    const redFlags = [
        "verify your account",
        "urgent action required",
        "login immediately",
        "account suspended",
        "confirm your password",
        "unusual activity",
        "act now"
    ];

    redFlags.forEach(flag => {
        if (text.includes(flag)) score++;
    });

    if (text.includes("dear customer")) score++;
    if (text.match(/http(s)?:\/\//g)) score++;
    if (text.match(/[A-Z]{6,}/g)) score++;
    if (text.includes("won") || text.includes("prize")) score++;

    if (score >= 5) return "Phishing Email";
    if (score >= 2) return "Suspicious Email";
    return "Safe Email";
}

/*************************************************
 * NAVIGATION
 *************************************************/
function goBack() {
    window.location.href = "index.html";
}
